// plugin from  Toxic-v2/xhclintohn thanks 🌟

let handler = async (m, { conn, text }) => {

  try {
    const query = text ? text.trim() : '';

    if (!query) {
      return m.reply(
        `╭───(    DEMON Bot    )───\n` +
        `├ ❗ انت نسيت تكتب حاجة\n` +
        `├ اكتب اسم أغنية أو لينك يوتيوب\n` +
        `├ مثال: .play عمرو دياب\n` +
        `╰──────────────────☉`
      );
    }

    await conn.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    if (query.length > 100) {
      return m.reply(
        `╭───(    DEMON Bot    )───\n` +
        `├ ❗ الطلب طويل شوية\n` +
        `├ حاول تختصره (حد أقصى 100 حرف)\n` +
        `╰──────────────────☉`
      );
    }

    const response = await fetch(`https://api.nexray.web.id/downloader/ytplay?q=${encodeURIComponent(query)}`);
    const data = await response.json();

    if (!data.status || !data.result?.download_url) {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return m.reply(
        `╭───(    Silana Bot    )───\n` +
        `├ ❌ ملقتش نتيجة لـ: "${query}"\n` +
        `├ جرب اسم تاني أو لينك مختلف\n` +
        `╰──────────────────☉`
      );
    }

    const result     = data.result;
    const audioUrl   = result.download_url;
    const filename   = result.title    || 'مقطع صوتي';
    const thumbnail  = result.thumbnail || '';
    const sourceUrl  = result.url       || '';
    const duration   = result.duration  || '';
    const views      = result.views     || '';

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    // إرسال الصوت بس
    await conn.sendMessage(m.chat, {
      audio: { url: audioUrl },
      mimetype: 'audio/mpeg',
      fileName: `${filename}.mp3`,
      contextInfo: thumbnail ? {
        externalAdReply: {
          title: filename.substring(0, 30),
          body: `🎧 ${duration} | 👁️ ${views}`,
          thumbnailUrl: thumbnail,
          sourceUrl: sourceUrl,
          mediaType: 1,
          renderLargerThumbnail: true,
        },
      } : undefined,
    }, { quoted: m });

  } catch (error) {
    console.error('Play error:', error);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    await m.reply(
      `╭───(    DEMON Bot    )───\n` +
      `├ ⚠️ حصل مشكلة\n` +
      `├ حاول تاني بعد شوية\n` +
      `╰──────────────────☉`
    );
  }
};

handler.help = ['شغل'];
handler.command = /^(شغل)?$/i;
handler.tags = ['downloader'];
handler.limit = true;

export default handler;