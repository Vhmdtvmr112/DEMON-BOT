let handler = async (m, { conn, text }) => {
   if (!text) return m.reply('_Enter Group Name!_')

   try {
      m.reply('_Creating group..._')

      // إنشاء الجروب
      let group = await conn.groupCreate(text, [m.sender])

      // جلب كود الدعوة
      let code = await conn.groupInviteCode(group.id)

      let link = 'https://chat.whatsapp.com/' + code

      m.reply(
`✅ Successfully Created Group

📌 Name: ${text}
🆔 ID: ${group.id}
🔗 Link: ${link}`
      )

   } catch (e) {
      console.error(e)
      m.reply('❌ Error while creating group')
   }
}

handler.help = ['creategroup']
handler.tags = ['owner']
handler.command = /^(creategroup)$/i
handler.owner = true

export default handler