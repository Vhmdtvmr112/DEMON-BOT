import axios from "axios";
import * as cheerio from "cheerio";

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply(
      "📌 الاستخدام:\n.story url | بداية النص | نهاية النص\n\nأو:\n.story url"
    );
  }

  let [url, startText, endText] = text.split("|").map(v => v?.trim());

  if (!url) return m.reply("❌ لازم تبعت رابط");

  m.reply('جاري استخراج القصة...')

  try {
    let { data } = await axios.get(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
      },
      timeout: 15000
    });

    const $ = cheerio.load(data);

    let textContent =
      $("article").text() ||
      $(".content").text() ||
      $("#content").text() ||
      $("main").text() ||
      $("body").text();

    textContent = textContent
      .replace(/\s+/g, " ")
      .replace(/[\u200B-\u200D\uFEFF]/g, "")
      .replace(/إعلان|اشترك|تابعنا|حقوق النشر/gi, "")
      .trim();

    let result = "";

    if (startText && endText) {
      let startIndex = textContent.indexOf(startText);
      if (startIndex !== -1) {
        let endIndex = textContent.indexOf(endText, startIndex);
        if (endIndex !== -1) {
          result = textContent.slice(
            startIndex,
            endIndex + endText.length
          );
        }
      }
    }

    if (!result || result.length < 50) {
      let paragraphs = [];
      $("p").each((i, el) => {
        let t = $(el).text().trim();
        if (
          t.length > 30 &&
          !t.includes("cookie") &&
          !t.includes("privacy") &&
          !t.includes("إعلان")
        ) {
          paragraphs.push(t);
        }
      });
      result = paragraphs.join("\n\n");
    }

    if (!result || result.length < 50) {
      return m.reply(
        "❌ لم أستطع استخراج الرواية من هذا الموقع\nقد يكون المحتوى محمي أو ديناميكي (JavaScript)"
      );
    }

    // التعديل هنا: شيلنا التقسيم وبنبعت ملف لو النص طويل
    if (result.length > 4000) {
      await conn.sendMessage(m.chat, {
        document: Buffer.from(result),
        mimetype: 'text/plain',
        fileName: `story_${Date.now()}.txt`,
        caption: `*تم استخراج القصة كاملة*\nالحجم: ${(result.length / 1024).toFixed(1)} KB\nعدد الحروف: ${result.length}`
      }, { quoted: m })
    } else {
      await m.reply(result);
    }

  } catch (err) {
    console.log(err);
    m.reply("❌ حصل خطأ أثناء جلب الصفحة");
  }
};

handler.command = /^story$/i;
handler.tags = ["tools"];
handler.help = ["story url | start | end"];
handler.owner = true

export default handler;