import fs from 'fs'
import path from 'path'

let handler = async (m, { text, command }) => {

    // مسار فولدر plugins الصحيح
    const pluginsDir = path.join(process.cwd(), 'plugins')

    // تأكد إن الفولدر موجود
    if (!fs.existsSync(pluginsDir)) {
        fs.mkdirSync(pluginsDir, { recursive: true })
    }

    // ====== استخراج النص ======
    const getQuotedText = async () => {
        if (!m.quoted) return null

        let q = m.quoted

        if (q.text) return q.text

        if (q.message?.conversation)
            return q.message.conversation

        if (q.message?.extendedTextMessage?.text)
            return q.message.extendedTextMessage.text

        if (q.mimetype) {
            let buffer = await q.download()
            return buffer.toString()
        }

        return null
    }

    // ====== حفظ ======
    if (command === 'احفظ') {

        if (!text) return m.reply('اكتب اسم الملف فقط بدون .js')
        if (!m.quoted) return m.reply('اعمل ريبلاي على الرسالة')

        let fileName = text.trim() + '.js'
        let filePath = path.join(pluginsDir, fileName)

        let code = await getQuotedText()

        if (!code) {
            return m.reply('❌ لم يتم قراءة الرسالة')
        }

        // تنظيف الكود
        code = code
        .replace(/```[a-z]*\n?/gi,'')
        .replace(/```/g,'')
        .trim()

        try {

            fs.writeFileSync(filePath, code)

            m.reply(
`✅ تم حفظ البلوجن
📁 ${fileName}

📌 المسار:
${filePath}`
            )

            console.log('Saved plugin at:', filePath)

            if (global.reload) global.reload()

        } catch (err) {

            console.log(err)
            m.reply('❌ حصل خطأ أثناء الحفظ')

        }
    }

    // ====== حذف ======
    if (command === 'امسح') {

        if (!text) return m.reply('اكتب اسم الملف فقط بدون .js')

        let fileName = text.trim() + '.js'
        let filePath = path.join(pluginsDir, fileName)

        if (!fs.existsSync(filePath)) {
            return m.reply('❌ الملف غير موجود')
        }

        try {

            fs.unlinkSync(filePath)

            m.reply(
`🗑️ تم حذف البلوجن
📁 ${fileName}`
            )

            console.log('Deleted plugin:', filePath)

            if (global.reload) global.reload()

        } catch (err) {

            console.log(err)
            m.reply('❌ حصل خطأ أثناء الحذف')

        }
    }
}

handler.command = ['احفظ','امسح']
handler.owner = true

export default handler