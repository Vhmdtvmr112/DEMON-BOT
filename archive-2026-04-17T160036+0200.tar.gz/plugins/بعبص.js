let handler = async (m, { conn }) => {
    // لازم يكون عامل منشن لحد
    let who = m.mentionedJid[0]
    if (!who) return m.reply('منشن اللي عايز تبعبصه طيب 😂\nمثال:.بعبص @عمر')

    // هنجيب الأرقام من غير @
    let sender = m.sender
    let target = who

    // النص اللي هيتبعت
    let text = `@${sender.split('@')[0]} بعبص @${target.split('@')[0]} 😂`

    // نبعت الرسالة ونعمل منشن للاتنين
    await conn.sendMessage(m.chat, {
        text: text,
        mentions: [sender, target]
    }, { quoted: m })
}

handler.help = ['بعبص @منشن']
handler.tags = ['fun']
handler.command = /^(بعبص|bo3bs)$/i

export default handler