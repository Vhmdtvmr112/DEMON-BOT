import axios from 'axios'
import cheerio from 'cheerio'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `ابعت لينك الصفحة\nمثال: ${usedPrefix + command} https://example.com/novel/ch1`
    if (!text.includes('http')) throw 'لازم لينك كامل http او https'

    m.reply('جاري سحب الـ HTML... لو الرواية فيها صفحات كتير هجيبهم كلهم')

    try {
        let allHtml = ''
        let currentUrl = text
        let pageCount = 0
        const maxPages = 50 // عشان ميعملش لووب لا نهائي

        while (currentUrl && pageCount < maxPages) {
            pageCount++
            const { data } = await axios.get(currentUrl, {
                headers: { 
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml',
                    'Accept-Language': 'ar,en-US;q=0.9'
                },
                timeout: 20000
            })
            
            const $ = cheerio.load(data)
            
            // شيل السكريبتات والستايل عشان الملف يبقى أخف
            $('script, style, noscript, iframe, ins, svg').remove()
            
            // خد محتوى الـ body بس عشان متكررش الـ head
            let bodyHtml = $('body').html() || data
            allHtml += `\n<!-- صفحة ${pageCount}: ${currentUrl} -->\n${bodyHtml}\n`
            
            // دور على لينك الصفحة الجاية بتاعت الرواية
            let nextLink = $('a:contains(التالي), a:contains(Next), a:contains(الفصل التالي), a[rel="next"]').attr('href')
            
            if (nextLink) {
                // لو اللينك نسبي حوله لمطلق
                if (!nextLink.startsWith('http')) {
                    const baseUrl = new URL(currentUrl).origin
                    nextLink = nextLink.startsWith('/') ? baseUrl + nextLink : baseUrl + '/' + nextLink
                }
                currentUrl = nextLink
                await new Promise(r => setTimeout(r, 1500)) // انتظر ثانية ونص عشان متبلعش بان
            } else {
                currentUrl = null // مفيش صفحة تانية
            }
        }

        // لف الـ HTML كله في صفحة واحدة
        let finalHtml = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>Scraped Content</title>
    <style>
        body { font-family: Arial; line-height: 1.8; padding: 20px; max-width: 800px; margin: auto; }
        img { max-width: 100%; height: auto; }
    </style>
</head>
<body>
${allHtml}
</body>
</html>`

        // لو الملف كبير ابعته مضغوط
        if (finalHtml.length > 60000) {
            await conn.sendMessage(m.chat, {
                document: Buffer.from(finalHtml),
                mimetype: 'text/html',
                fileName: `scraped_${Date.now()}.html`,
                caption: `*تم سحب ${pageCount} صفحة*\nالحجم: ${(finalHtml.length / 1024).toFixed(1)} KB\nافتحه في المتصفح وشوف السورس`
            }, { quoted: m })
        } else {
            // لو صغير ابعته ككود علطول
            let preview = finalHtml.length > 4000 ? finalHtml.slice(0, 4000) + '\n...' : finalHtml
            await m.reply(`*الـ HTML كامل:*\n\`\`\`html\n${preview}\n\`\`\``)
        }

    } catch (e) {
        console.log(e)
        m.reply(`فشل السحب: ${e.message}\nالموقع ممكن يكون محمي بـ Cloudflare أو محتاج Puppeteer`)
    }
}

handler.help = ['سحب <لينك>']
handler.tags = ['tools']
handler.command = /^(سحب|grabhtml|gethtml)$/i
handler.limit = true
handler.owner = true

export default handler