let handler = async (m, { conn, text }) => {

  if (!m.quoted) throw '✳️ اعمل ريبلاي على رسالة'

  let link = text.match(/chat\.whatsapp\.com\/([0-9A-Za-z]+)/i)
  if (!link) throw '✳️ حط لينك الجروب'

  let code = link[1]

  // 👇 الحل هنا
  let info = await conn.groupGetInviteInfo(code)
  let target = info.id

  let metadata = await conn.groupMetadata(target)

  let users = metadata.participants
    .map(u => u.id)
    .filter(v => v !== conn.user.jid)

  await conn.sendMessage(target, {
    forward: m.quoted.fakeObj,
    mentions: users
  })

}

handler.help = ['الكل [لينك جروب]']
handler.tags = ['owner']
handler.command = /^(منشن|الكل)$/i
handler.group = false

export default handler