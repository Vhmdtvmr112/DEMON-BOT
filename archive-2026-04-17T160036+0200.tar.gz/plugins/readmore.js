let handler = async (m, { text, usedPrefix, command }) => {
    // لو بترد على رسالة، خد النص منها
    if (m.quoted && m.quoted.text &&!text) {
        text = m.quoted.text
    }

    if (!text) {
        return m.reply(`الاستخدام:\n${usedPrefix + command} النص القصير | النص الطويل\n\nأو رد على رسالة طويلة واكتب ${usedPrefix + command}`)
    }

    let shortText, longText

    // لو فيه | يبقى المستخدم محدد النص القصير والطويل
    if (text.includes('|')) {
        // split مرة واحدة بس عشان لو فيه | تاني في النص
        let parts = text.split('|')
        shortText = parts[0].trim()
        longText = parts.slice(1).join('|') // باقي النص كله حتى لو فيه |
    } else {
        // لو مفيش | اقسم النص تلقائي بعد أول 100 حرف
        shortText = text.slice(0, 100).trim()
        longText = text.slice(100)
    }

    if (!longText) return m.reply('النص قصير جداً، اكتب نص أطول')

    // الحرف السحري + سطر جديد عشان النص ينزل لتحت
    const readMore = String.fromCharCode(8206).repeat(4001)
    const message = `${shortText}${readMore}\n${longText.trimStart()}`

    await m.reply(message)
}

handler.help = ['readmore <نص>']
handler.tags = ['tools']
handler.command = /^(readmore|المزيد|قراءة)$/i

export default handler