import axios from 'axios'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const baseURL = 'https://api.mail.tm'

    //.tempmail جديد
    if (command == 'ايميل' || command == 'tempmail') {
        m.reply('جاري انشاء ايميل مؤقت...')

        try {
            // 1. نجيب الدومينات المتاحة
            let { data: domains } = await axios.get(`${baseURL}/domains`)
            let domain = domains['hydra:member'][0].domain

            // 2. نعمل ايميل عشوائي
            let randomName = Math.random().toString(36).substring(2, 12)
            let email = `${randomName}@${domain}`
            let password = Math.random().toString(36).substring(2, 12)

            // 3. نسجل حساب
            await axios.post(`${baseURL}/accounts`, {
                address: email,
                password: password
            })

            // 4. نسجل دخول عشان ناخد التوكن
            let { data: auth } = await axios.post(`${baseURL}/token`, {
                address: email,
                password: password
            })
            let token = auth.token

            // نخزن التوكن في داتا اليوزر عشان يستخدمه بعدين
            if (!global.db.data.users[m.sender].tempmail) global.db.data.users[m.sender].tempmail = {}
            global.db.data.users[m.sender].tempmail = { email, password, token }

            let msg = `*📧 تم انشاء ايميل مؤقت*\n\n`
            msg += `*الايميل:* \`${email}\`\n`
            msg += `*الباسورد:* \`${password}\`\n\n`
            msg += `استخدم \`${usedPrefix}صندوق\` عشان تشوف الرسايل\n`
            msg += `الايميل صالح ساعة واحدة`

            m.reply(msg)

        } catch (e) {
            console.log(e.response?.data || e)
            m.reply('فشل انشاء الايميل، جرب تاني')
        }
    }

    //.صندوق
    if (command == 'صندوق' || command == 'inbox') {
        let userData = global.db.data.users[m.sender].tempmail
        if (!userData) throw `معندكش ايميل مؤقت\nاعمل واحد بـ ${usedPrefix}ايميل`

        m.reply('جاري جلب الرسائل...')

        try {
            let { data: messages } = await axios.get(`${baseURL}/messages`, {
                headers: { Authorization: `Bearer ${userData.token}` }
            })

            let msgs = messages['hydra:member']
            if (msgs.length === 0) return m.reply('صندوق الوارد فاضي')

            let text = `*📬 صندوق وارد ${userData.email}*\n\n`
            for (let i = 0; i < msgs.length; i++) {
                let msg = msgs[i]
                text += `*${i+1}. من:* ${msg.from.address}\n`
                text += `*الموضوع:* ${msg.subject}\n`
                text += `*ID:* \`${msg.id}\`\n`
                text += `شوفها بـ ${usedPrefix}رسالة ${msg.id}\n\n`
            }
            m.reply(text)

        } catch (e) {
            m.reply('انتهت صلاحية الايميل. اعمل واحد جديد')
            delete global.db.data.users[m.sender].tempmail
        }
    }

    //.رسالة
    if (command == 'رسالة' || command == 'read') {
        if (!text) throw `اكتب ID الرسالة\nمثال: ${usedPrefix}رسالة 12345`

        let userData = global.db.data.users[m.sender].tempmail
        if (!userData) throw `معندكش ايميل مؤقت`

        try {
            let { data: msg } = await axios.get(`${baseURL}/messages/${text}`, {
                headers: { Authorization: `Bearer ${userData.token}` }
            })

            let body = msg.text || msg.html || 'رسالة فاضية'
            let reply = `*📩 من:* ${msg.from.address}\n`
            reply += `*👤 الى:* ${msg.to[0].address}\n`
            reply += `*📝 الموضوع:* ${msg.subject}\n`
            reply += `*📅 التاريخ:* ${new Date(msg.createdAt).toLocaleString('ar-EG')}\n\n`
            reply += `*الرسالة:*\n${body.slice(0, 4000)}` // واتساب اخره 4k حرف

            m.reply(reply)

        } catch (e) {
            m.reply('الرسالة مش موجودة او انتهت الصلاحية')
        }
    }
}

handler.help = ['ايميل', 'صندوق', 'رسالة <id>']
handler.tags = ['tools']
handler.command = /^(ايميل|tempmail|صندوق|inbox|رسالة|read)$/i
handler.limit = true

export default handler