// @noureddine_ouafy

import { toPTT } from '../lib/converter.js'

let handler = async (m, { conn, usedPrefix, command, text }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (m.quoted ? m.quoted : m.msg).mimetype || ''

  if (!/video|audio/.test(mime)) {
    throw `Reply to a video/audio with *${usedPrefix + command}*`
  }

  let target = m.chat

  // ===== 1. لو رقم =====
  let number = text ? text.replace(/[^0-9]/g, '') : null

  // ===== 2. لو لينك واتساب =====
  let groupLink = text?.match(/chat\.whatsapp\.com\/([0-9A-Za-z]+)/i)
  let channelLink = text?.match(/whatsapp\.com\/channel\/([0-9A-Za-z]+)/i)

  try {
    if (groupLink) {
      let code = groupLink[1]
      let res = await conn.groupAcceptInvite(code)
      target = res // JID بتاع الجروب
    } else if (channelLink) {
      let code = channelLink[1]
      let res = await conn.newsletterMetadata("invite", code)
      target = res.id // JID بتاع القناة
    } else if (number) {
      target = number + '@s.whatsapp.net'
    }
  } catch (e) {
    throw 'Invalid link or bot cannot access the group/channel.'
  }

  let media = await q.download?.()
  if (!media) throw 'Failed to download media.'

  let audio = await toPTT(media, 'mp4')
  if (!audio.data) throw 'Conversion failed.'

  // بدون ريبلاي
  await conn.sendFile(target, audio.data, 'audio.mp3', '', null, true, {
    mimetype: 'audio/mp4'
  })
}

handler.help = ['tovn [number | group link | channel link]']
handler.tags = ['tools']
handler.command = /^to(vn|(ptt)?)$/i
handler.limit = 4

export default handler