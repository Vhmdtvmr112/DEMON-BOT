import * as baileys from '@adiwajshing/baileys'
import fs from 'fs'
import pino from 'pino'

// 🔥 حل مشكلة makeWASocket لأي نسخة
const makeWASocket = baileys.default || baileys.makeWASocket

const {
   useMultiFileAuthState,
   fetchLatestBaileysVersion,
   DisconnectReason
} = baileys

let handler = async (m, { conn, text }) => {
   if (!text) throw 'اكتب رقمك مع كود الدولة\nمثال:\n.jadibot 2010xxxxxxxx'

   const phoneNumber = text.replace(/[^0-9]/g, '')
   const sessionPath = `./jadibot/${phoneNumber}`

   if (!fs.existsSync(sessionPath)) {
      fs.mkdirSync(sessionPath, { recursive: true })
   }

   const { state, saveCreds } = await useMultiFileAuthState(sessionPath)
   const { version } = await fetchLatestBaileysVersion()

   const sock = makeWASocket({
      auth: state,
      version,
      printQRInTerminal: false,
      logger: pino({ level: 'silent' }),
      browser: ['Ubuntu', 'Chrome', '20.0.04']
   })

   let codeSent = false

   sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect } = update

      if (connection === 'connecting' && !sock.authState.creds.registered && !codeSent) {
         codeSent = true
         try {
            const code = await sock.requestPairingCode(phoneNumber)
            await conn.reply(m.chat, `🔑 كود الربط:\n\n${code}`, m)
         } catch (err) {
            console.log(err)
            conn.reply(m.chat, '❌ فشل في استخراج الكود', m)
         }
      }

      if (connection === 'open') {
         conn.reply(m.chat, '✅ تم الربط بنجاح', m)
      }

      if (connection === 'close') {
         const reason = lastDisconnect?.error?.output?.statusCode

         if (reason === DisconnectReason.loggedOut) {
            conn.reply(m.chat, '❌ تم تسجيل الخروج — امسح الجلسة', m)
         } else {
            conn.reply(m.chat, '⚠️ إعادة الاتصال...', m)
            setTimeout(() => handler(m, { conn, text }), 3000)
         }
      }
   })

   sock.ev.on('creds.update', saveCreds)
}

handler.command = /^jadibot$/i
export default handler