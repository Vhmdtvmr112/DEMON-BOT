let handler = async (m, { conn, text }) => {

  if (!m.quoted) throw '✳️ اعمل ريبلاي على الحالة'

  let link = text.match(/chat\.whatsapp\.com\/([0-9A-Za-z]+)/i)
  if (!link) throw '✳️ حط لينك الجروب'

  let code = link[1]

  let info = await conn.groupGetInviteInfo(code)
  let groupJid = info.id

  let q = m.quoted
  let message = {}

  // ===== نص =====
  if (q.mtype === 'conversation' || q.mtype === 'extendedTextMessage') {
    message = {
      text: q.text
    }
  }

  // ===== صورة =====
  else if (q.mtype === 'imageMessage') {
    message = {
      image: await q.download(),
      caption: q.caption || ''
    }
  }

  // ===== فيديو =====
  else if (q.mtype === 'videoMessage') {
    message = {
      video: await q.download(),
      caption: q.caption || ''
    }
  }

  // ===== صوت =====
  else if (q.mtype === 'audioMessage') {
    message = {
      audio: await q.download(),
      mimetype: 'audio/mp4',
      ptt: true
    }
  }

  else {
    throw '❌ نوع غير مدعوم'
  }

  // ✅ هنا السحر الحقيقي
  await conn.sendMessage(groupJid, {
    groupStatusMessage: message
  })

  m.reply('✅ تم نشر الحالة كـ Group Status فعلي')

}

handler.command = /^حالة$/i
handler.group = false

export default handler