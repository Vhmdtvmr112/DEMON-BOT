import axios from 'axios'
import cheerio from 'cheerio'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `ابعت لينك الموقع\nمثال: ${usedPrefix + command} https://example.com`
    if (!text.includes('http')) throw 'لازم لينك كامل http او https'

    m.reply('جاري فحص الموقع...')

    try {
        const { data } = await axios.get(text, {
            headers: { 'User-Agent': 'Mozilla/5.0' }, // عشان ميعملش بلوك
            timeout: 10000
        })
        const $ = cheerio.load(data)

        // 1. العنوان والوصف
        let title = $('title').text().trim() || 'مش لاقي'
        let desc = $('meta[name="description"]').attr('content') || 'مفيش وصف'

        // 2. هل فيه API؟ ندور على fetch, xhr, json
        let scripts = ''
        $('script').each((i, el) => {
            scripts += $(el).html()
        })
        let hasAPI = /fetch\(|axios\.|\.ajax|\.getJSON|api\//i.test(scripts)
        let apiEndpoints = [...new Set(scripts.match(/\/api\/[a-zA-Z0-9/_-]+/g) || [])]

        // 3. الفورمات
        let forms = []
        $('form').each((i, el) => {
            forms.push({
                action: $(el).attr('action') || '/',
                method: $(el).attr('method') || 'get',
                inputs: $(el).find('input').map((i, inp) => $(inp).attr('name')).get().filter(Boolean)
            })
        })

        // 4. أهم السيلكتورز اللي فيها داتا غالباً
        let selectors = []
        $('[class*="item"], [class*="card"], [class*="post"], [class*="product"], article,.entry').slice(0, 3).each((i, el) => {
            let className = $(el).attr('class')
            if (className) selectors.push('.' + className.split(' ')[0])
        })
        selectors = [...new Set(selectors)]

        // 5. لينكات الـ pagination
        let nextPage = $('a[rel="next"]').attr('href') || $('a:contains(التالي)').attr('href') || $('a:contains(Next)').attr('href')

        // 6. هل الموقع بيحتاج JS؟ يعني لو لقينا #root فاضية يبقى React
        let needJS = $('#root, #app, #__next').length > 0 && $('body').text().trim().length < 200

        // تجميع التقرير
        let report = `*📊 تقرير فحص: ${title}*\n\n`
        report += `*الوصف:* ${desc}\n`
        report += `*بيحتاج متصفح JS:* ${needJS? 'اه - استخدم Puppeteer' : 'لا - Axios يكفي'}\n\n`

        report += `*API موجود؟* ${hasAPI? 'اه ✅' : 'لا ❌'}\n`
        if (apiEndpoints.length) report += `*Endpoints لقيتها:*\n${apiEndpoints.slice(0,5).join('\n')}\n\n`

        if (forms.length) {
            report += `*الفورمات:*\n`
            forms.forEach((f, i) => {
                report += `${i+1}. ${f.method.toUpperCase()} ${f.action}\n inputs: ${f.inputs.join(', ')}\n`
            })
            report += '\n'
        }

        if (selectors.length) {
            report += `*Selectors مهمة للداتا:*\n${selectors.join('\n')}\n\n`
        }

        if (nextPage) report += `*لينك الصفحة الجاية:* ${nextPage}\n\n`

        report += `*كود Cheerio جاهز للتجربة:*\n`
        report += `\`\`\`js\nconst $ = cheerio.load(html)\n$('${selectors[0] || 'body'}').each((i, el) => {\n let data = $(el).text()\n})\n\`\`\``

        await m.reply(report)

    } catch (e) {
        console.log(e)
        m.reply('فشل الفحص. الموقع ممكن يكون حاظر السكراب أو محتاج Puppeteer')
    }
}

handler.help = ['سكراب <لينك>']
handler.tags = ['tools']
handler.command = /^(سكراب|scrape)$/i
handler.limit = true

export default handler