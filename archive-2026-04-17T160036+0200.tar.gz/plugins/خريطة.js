import axios from 'axios'
import * as cheerio from 'cheerio'

const userAgents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148'
]

async function fetchPage(url, uaIndex = 0) {
    try {
        let { data } = await axios.get(url, {
            headers: {
                'User-Agent': userAgents[uaIndex],
                'Accept': 'text/html,application/xhtml+xml',
                'Accept-Language': 'ar,en-US;q=0.9',
                'Referer': 'https://www.google.com/'
            },
            timeout: 25000,
            maxRedirects: 5
        })
        return data
    } catch (e) {
        if (uaIndex < userAgents.length - 1) return fetchPage(url, uaIndex + 1)
        throw e
    }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `الاستخدام:\n${usedPrefix + command} <لينك> → يجيب الأقسام\n${usedPrefix + command} <لينك_القسم> | قسم → يجيب كل القصص اللي في كل صفحات القسم`

    let [url, mode] = text.split('|').map(v => v?.trim())
    if (!url.startsWith('http')) return m.reply('لازم اللينك يبدأ بـ http او https')

    m.reply('جاري فحص الموقع... لو القسم فيه صفحات كتير هجيبهم كلهم')

    try {
        let data = await fetchPage(url)
        const $ = cheerio.load(data)
        const baseUrl = new URL(url).origin

        // MODE 1: جيب الأقسام
        if (!mode) {
            let categories = new Map()
            $('a').each((i, el) => {
                let href = $(el).attr('href')
                let title = $(el).text().trim().replace(/\s+/g, ' ')
                if (!href ||!title || title.length < 3 || title.length > 60) return

                let isCategory = /category|section|forum|cat|قسم|تصنيف|\/c\/|\/f\/|board/i.test(href)
                let isMenu = $(el).parents('nav,.menu,.navbar,.categories,.sidebar,header').length > 0

                if (isCategory || isMenu) {
                    if (!href.startsWith('http')) href = href.startsWith('/')? baseUrl + href : baseUrl + '/' + href
                    if (!categories.has(href) && href.includes(baseUrl)) categories.set(href, title)
                }
            })

            if (categories.size === 0) return m.reply('ملقتش أقسام واضحة. جرب لينك القسم مباشرة')

            let list = `*📂 الأقسام: ${categories.size}*\n\n`
            let index = 1
            for (let [link, name] of categories) {
                list += `*${index}.* ${name}\n${link}\n\n`
                index++
                if (index > 25) break
            }
            list += `\nلجلب كل القصص في قسم: ${usedPrefix + command} <لينك_القسم> | قسم`
            return m.reply(list)
        }

        // MODE 2: جيب كل المواضيع من كل صفحات القسم
        if (mode === 'قسم') {
            let allTopics = []
            let currentUrl = url
            let pageCount = 0
            const maxPages = 20 // عشان ميعملش لووب لا نهائي
            let seenLinks = new Set()

            while (currentUrl && pageCount < maxPages) {
                pageCount++
                await m.reply(`بفحص صفحة ${pageCount}...`)

                let pageData = pageCount === 1? data : await fetchPage(currentUrl)
                let $page = cheerio.load(pageData)

                // سيلكتورز المواضيع
                let selectors = '.thread-title a,.topic-title a,h2 a,h3 a,.title a,article h2 a,a[href*="thread"],a[href*="topic"],a[href*="/t/"]'

                $page(selectors).each((i, el) => {
                    let href = $page(el).attr('href')
                    let title = $page(el).text().trim().replace(/\s+/g, ' ')

                    if (href && title && title.length > 5) {
                        if (!href.startsWith('http')) href = href.startsWith('/')? baseUrl + href : baseUrl + '/' + href
                        // شيل المكرر وشيل لينكات الأقسام
                        if (!seenLinks.has(href) &&!/category|forum|page/i.test(href)) {
                            seenLinks.add(href)
                            allTopics.push({ title, link: href })
                        }
                    }
                })

                // دور على زر "التالي" أو "Next" أو رقم الصفحة اللي بعدها
                let nextLink = $page('a:contains(التالي), a:contains(Next), a[rel="next"], a:contains("»"),.pagination.next a').attr('href')

                // لو ملقاش "التالي" جرب يدور على رقم الصفحة +1
                if (!nextLink) {
                    let currentPageNum = parseInt(currentUrl.match(/page[=-](\d+)/)?.[1] || '1')
                    nextLink = $page(`a:contains("${currentPageNum + 1}")`).attr('href')
                }

                if (nextLink) {
                    if (!nextLink.startsWith('http')) {
                        nextLink = nextLink.startsWith('/')? baseUrl + nextLink : baseUrl + '/' + nextLink
                    }
                    currentUrl = nextLink
                    await new Promise(r => setTimeout(r, 2000)) // انتظر ثانيتين بين كل صفحة
                } else {
                    currentUrl = null // مفيش صفحات تاني
                }
            }

            if (allTopics.length === 0) return m.reply('ملقتش مواضيع في القسم ده')

            let result = `*📑 كل القصص في القسم: ${allTopics.length} من ${pageCount} صفحة*\n\n`
            allTopics.slice(0, 30).forEach((t, i) => {
                result += `*${i + 1}.* ${t.title}\n${t.link}\n\n`
            })

            // ابعت ملف دايماً عشان العدد كبير
            let fileContent = allTopics.map((t, i) => `${i + 1}. ${t.title}\n${t.link}\n`).join('\n')
            await conn.sendMessage(m.chat, {
                document: Buffer.from(fileContent),
                mimetype: 'text/plain',
                fileName: `all_topics_${Date.now()}.txt`,
                caption: `*تم سحب ${allTopics.length} قصة من ${pageCount} صفحة*\nافتح الملف هتلاقي كل قصة باللينك بتاعها`
            }, { quoted: m })
        }

    } catch (e) {
        console.log(e)
        let msg = `فشل الفحص: ${e.message}\n`
        if (e.response?.status === 404) msg += 'السبب: الصفحة مش موجودة 404'
        else if (e.response?.status === 403) msg += 'السبب: الموقع عامل بلوك 403'
        else msg += 'الموقع ممكن يكون محمي بـ Cloudflare'
        m.reply(msg)
    }
}

handler.help = ['خريطة <لينك>']
handler.tags = ['tools']
handler.command = /^(خريطة|map|اقسام)$/i
handler.limit = true
handler.owner = true

export default handler