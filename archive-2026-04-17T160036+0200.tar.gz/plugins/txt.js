let handler = async (m, { conn }) => {
    let q = m.quoted? m.quoted : m

    if (!q.mimetype ||!q.mimetype.includes('text')) {
        return m.reply('منشن على ملف txt')
    }

    try {
        let buffer = await q.download()
        let text = buffer.toString('utf-8').replace(/\r\n/g, '\n').trim()

        if (!text) return m.reply('الملف فاضي')

        const maxLength = 4000
        let parts = []
        let currentPart = ''
        let lines = text.split('\n')

        for (let line of lines) {
            if (line.length > maxLength) {
                let words = line.split(' ')
                for (let word of words) {
                    if ((currentPart + word).length > maxLength) {
                        if (currentPart) parts.push(currentPart.trim())
                        currentPart = word + ' '
                    } else {
                        currentPart += word + ' '
                    }
                }
            } else {
                if ((currentPart + line + '\n').length > maxLength) {
                    if (currentPart) parts.push(currentPart.trim())
                    currentPart = line + '\n'
                } else {
                    currentPart += line + '\n'
                }
            }
        }

        if (currentPart.trim()) parts.push(currentPart.trim())

        // ابعت رسالة العدد بس لو النص كبير
        if (parts.length > 1) {
            await m.reply(`الملف كبير، هبعته على ${parts.length} أجزاء:`)
            await new Promise(r => setTimeout(r, 1000))
        }

        // ابعت الأجزاء
        for (let i = 0; i < parts.length; i++) {
            if (i > 0) await new Promise(r => setTimeout(r, 1500))
            await m.reply(parts.length > 1? `*${i + 1}/${parts.length}*\n\n${parts[i]}` : parts[i])
        }

    } catch (e) {
        console.log(e)
        m.reply('الخطأ: ' + e.message)
    }
}

handler.help = ['txt']
handler.tags = ['tools']
handler.command = /^(txt|اقرا)$/i

export default handler