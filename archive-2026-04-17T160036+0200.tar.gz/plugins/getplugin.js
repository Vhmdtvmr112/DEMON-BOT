import fs from 'fs'
import path from 'path'

let handler = async (m, { isROwner, command, text }) => {

    if (!isROwner) return

    const pluginsDir = path.join(process.cwd(), 'plugins')

    switch (command) {

        // ====== عرض بلوجن / عرض القائمة ======
        case 'gp':
        case 'getplugin':

            let files = fs.readdirSync(pluginsDir)
                .filter(v => v.endsWith('.js'))
                .map(v => v.replace('.js', ''))

            // لو مفيش اسم → اعرض القائمة
            if (!text) {
                if (files.length === 0) {
                    return m.reply('❌ لا يوجد بلوجنز')
                }

                return m.reply(
`📂 قائمة البلوجنز:

${files.map(v => '• ' + v).join('\n')}

📌 للاستخدام:
getplugin اسم_البلوجن`
                )
            }

            let fileName = text.trim() + '.js'
            let filePath = path.join(pluginsDir, fileName)

            if (!fs.existsSync(filePath)) {
                return m.reply(
`❌ البلوجن غير موجود

📂 المتاح:
${files.map(v => '• ' + v).join('\n')}`
                )
            }

            try {
                let code = fs.readFileSync(filePath, 'utf-8')
                m.reply(code)
            } catch (e) {
                console.log(e)
                m.reply('❌ خطأ أثناء القراءة')
            }

        break


        // ====== قراءة أي ملف ======
        case 'gf':

            if (!text) return m.reply('اكتب مسار الملف')

            let fullPath = path.join(process.cwd(), text)

            if (!fs.existsSync(fullPath)) {
                return m.reply('❌ الملف غير موجود')
            }

            try {
                let data = fs.readFileSync(fullPath, 'utf-8')
                m.reply(data)
            } catch (e) {
                console.log(e)
                m.reply('❌ خطأ أثناء القراءة')
            }

        break
    }
}

handler.help = ['getplugin', 'gp', 'gf']
handler.command = ['getplugin','gp','gf']
handler.tags = ['owner']
handler.rowner = true

export default handler