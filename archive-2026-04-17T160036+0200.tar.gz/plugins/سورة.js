import axios from 'axios'
import cheerio from 'cheerio'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const baseURL = 'https://www.mp3quran.net/ar'

    //.قارئ اسم القارئ
    if (command == 'قارئ' || command == 'reciter') {
        if (!text) throw `اكتب اسم القارئ\nمثال: ${usedPrefix}قارئ عبد الباسط`

        m.reply('جاري البحث عن القارئ...')

        try {
            let { data } = await axios.get(`${baseURL}/search`, {
                params: { s: text },
                headers: { 'User-Agent': 'Mozilla/5.0' }
            })
            let $ = cheerio.load(data)

            let results = []
            $('.tb-search.row').each((i, el) => {
                let name = $(el).find('.col-md-8 a').text().trim()
                let link = $(el).find('.col-md-8 a').attr('href')
                let rewayat = $(el).find('.col-md-4').text().trim()
                if (name && link) {
                    results.push({ name, link: `https://www.mp3quran.net${link}`, rewayat })
                }
            })

            if (results.length === 0) throw 'ملقتش القارئ ده، اتأكد من الاسم'

            let msg = `*📖 نتائج البحث عن: ${text}*\n\n`
            results.slice(0, 10).forEach((r, i) => {
                msg += `*${i + 1}. ${r.name}*\n`
                msg += `الرواية: ${r.rewayat}\n`
                msg += `عرض السور: ${usedPrefix}سور ${r.link}\n\n`
            })
            m.reply(msg)

        } catch (e) {
            console.log(e)
            m.reply('حصل خطأ في البحث')
        }
    }

    //.سور لينك_القارئ
    if (command == 'سور' || command == 'surahs') {
        if (!text ||!text.includes('mp3quran.net')) throw `ابعت لينك صفحة القارئ\nجيبه من أمر ${usedPrefix}قارئ\nمثال: ${usedPrefix}سور https://www.mp3quran.net/ar/abasit`

        m.reply('جاري جلب السور...')

        try {
            let { data } = await axios.get(text, {
                headers: { 'User-Agent': 'Mozilla/5.0' }
            })
            let $ = cheerio.load(data)

            let reciterName = $('h1').first().text().trim()
            let surahs = []

            $('.sura-item').each((i, el) => {
                let suraName = $(el).find('.sura-name').text().trim()
                let downloadLink = $(el).find('a.download').attr('href')
                if (suraName && downloadLink) {
                    surahs.push({ suraName, downloadLink })
                }
            })

            if (surahs.length === 0) throw 'ملقتش سور في الصفحة دي'

            // نخزن اللينكات عشان اليوزر يحمل بعدها
            if (!global.db.data.users[m.sender].quran) global.db.data.users[m.sender].quran = {}
            global.db.data.users[m.sender].quran[reciterName] = surahs

            let msg = `*🎙️ سور القارئ: ${reciterName}*\n`
            msg += `*عدد السور:* ${surahs.length}\n\n`
            msg += `اكتب ${usedPrefix}حمل ${reciterName} رقم_السورة\n`
            msg += `مثال: ${usedPrefix}حمل ${reciterName} 1\n\n`
            msg += `*أول 15 سورة:*\n`
            surahs.slice(0, 15).forEach((s, i) => {
                msg += `${i + 1}. ${s.suraName}\n`
            })
            if (surahs.length > 15) msg += `\n...و ${surahs.length - 15} سورة تانية`

            m.reply(msg)

        } catch (e) {
            console.log(e)
            m.reply('فشل جلب السور، اتأكد من اللينك')
        }
    }

    //.حمل اسم_القارئ رقم_السورة
    if (command == 'حمل' || command == 'download') {
        let [reciterName, suraNum] = text.split('|').map(v => v.trim())
        if (!reciterName ||!suraNum) throw `الاستخدام: ${usedPrefix}حمل اسم_القارئ|رقم_السورة\nمثال: ${usedPrefix}حمل عبد الباسط عبد الصمد|1`

        let userData = global.db.data.users[m.sender].quran
        if (!userData ||!userData[reciterName]) throw `لازم تجيب السور الأول بـ ${usedPrefix}سور لينك_القارئ`

        let surahs = userData[reciterName]
        let index = parseInt(suraNum) - 1
        if (isNaN(index) || index < 0 || index >= surahs.length) throw `رقم السورة غلط. اختار من 1 لـ ${surahs.length}`

        let sura = surahs[index]
        m.reply(`جاري ارسال *${sura.suraName}* بصوت *${reciterName}*...`)

        try {
            await conn.sendMessage(m.chat, {
                audio: { url: sura.downloadLink },
                mimetype: 'audio/mpeg',
                fileName: `${sura.suraName} - ${reciterName}.mp3`
            }, { quoted: m })
        } catch (e) {
            m.reply(`فشل الارسال. حملها من هنا:\n${sura.downloadLink}`)
        }
    }
}

handler.help = ['قارئ <اسم>', 'سور <لينك>', 'حمل <قارئ|رقم>']
handler.tags = ['tools', 'quran']
handler.command = /^(قارئ|reciter|سور|surahs|حمل|download)$/i
handler.limit = true

export default handler