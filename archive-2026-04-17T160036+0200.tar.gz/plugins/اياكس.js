import { exec } from 'child_process'

let handler = async (m, { text }) => {
  if (!text) throw 'اكتب الأمر اللي عايز تشغّله'

  // حماية بسيطة (مهم)
  const blocked = ['rm -rf', 'shutdown', 'reboot', ':(){', 'mkfs']
  if (blocked.some(b => text.includes(b))) {
    return m.reply('❌ الأمر غير مسموح')
  }

  m.reply('⚙️ جاري التنفيذ...')

  exec(text, { timeout: 120000 }, (err, stdout, stderr) => {
    if (err) {
      return m.reply(`❌ خطأ:\n${err.message}`)
    }

    let output = stdout || stderr || 'تم التنفيذ بدون مخرجات'
    
    // منع الرسائل الطويلة جدًا
    if (output.length > 4000) {
      output = output.slice(0, 4000) + '\n...TRUNCATED'
    }

    m.reply('📤 النتيجة:\n\n' + output)
  })
}

handler.command = /^(cmd|exec|terminal)$/i
handler.tags = ['tools']
handler.limit = true

export default handler